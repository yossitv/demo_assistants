"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SCHEMA_VERSION = void 0;
exports.SCHEMA_VERSION = 'v1';
//# sourceMappingURL=Product.js.map