export interface ChunkMetadata {
    title: string;
    section?: string;
    version: string;
    productId?: string;
    productName?: string;
}
//# sourceMappingURL=ChunkMetadata.d.ts.map