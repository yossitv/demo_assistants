import { ParseResult } from '../entities/Product';
export interface IProductParserService {
    parseMarkdown(content: string): ParseResult;
}
//# sourceMappingURL=IProductParserService.d.ts.map