"use strict";
// Interface for embedding generation service
// Requirements: 1.5 - Generate embeddings for chunks using consistent embedding model
Object.defineProperty(exports, "__esModule", { value: true });
//# sourceMappingURL=IEmbeddingService.js.map