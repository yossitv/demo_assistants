"use strict";
// Interface for LLM (Large Language Model) service
// Requirements: 4.14 - Call LLM API to generate assistant's response
Object.defineProperty(exports, "__esModule", { value: true });
//# sourceMappingURL=ILLMService.js.map