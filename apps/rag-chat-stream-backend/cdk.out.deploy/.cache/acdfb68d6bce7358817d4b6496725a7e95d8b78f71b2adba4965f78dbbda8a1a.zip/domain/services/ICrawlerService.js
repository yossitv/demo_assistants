"use strict";
// Interface for web crawling service
// Requirements: 1.3 - Crawl URLs and extract main text content
Object.defineProperty(exports, "__esModule", { value: true });
//# sourceMappingURL=ICrawlerService.js.map