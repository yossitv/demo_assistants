"use strict";
// Interface for text chunking service
// Requirements: 1.4 - Split content into chunks of 400-600 tokens with 50-100 tokens overlap
Object.defineProperty(exports, "__esModule", { value: true });
//# sourceMappingURL=IChunkingService.js.map