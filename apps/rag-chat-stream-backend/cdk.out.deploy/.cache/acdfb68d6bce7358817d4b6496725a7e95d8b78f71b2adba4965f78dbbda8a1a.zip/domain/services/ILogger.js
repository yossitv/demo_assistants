"use strict";
// Interface for logging service
// Requirements: 7.1 - Log operations to CloudWatch for debugging
Object.defineProperty(exports, "__esModule", { value: true });
//# sourceMappingURL=ILogger.js.map