import { APIGatewayProxyEvent, APIGatewayProxyResult } from '../shared/types';
export declare const handler: (event: APIGatewayProxyEvent) => Promise<APIGatewayProxyResult>;
//# sourceMappingURL=productKnowledgeCreate.d.ts.map